package com.murach.tipcalculator;

public class getTips {
}
