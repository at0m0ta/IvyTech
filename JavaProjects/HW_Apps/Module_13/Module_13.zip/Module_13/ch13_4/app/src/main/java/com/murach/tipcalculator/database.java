package com.murach.tipcalculator;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class database {

    //database constraints
    public static final String DB_NAME = "database.db";
    public static final int DB_VERSION = 1;

    //list table constraints
    public static final String LIST_TABLE = "list";

    public static final String LIST_ID = "_id";
    public static final int LIST_ID_COL = 0;

    public static final String



    //task table constraints


    //CREATE and DROP TABLE statements



}
