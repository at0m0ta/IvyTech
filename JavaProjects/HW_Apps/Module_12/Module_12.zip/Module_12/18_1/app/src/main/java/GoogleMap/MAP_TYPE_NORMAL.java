package GoogleMap;

/**
 *
 */
public class MAP_TYPE_NORMAL {
}
