package GoogleMap

class MAP_TYPE_NORMALTest extends GroovyTestCase {
}
